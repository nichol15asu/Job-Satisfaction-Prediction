import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PredictionResult as PredictionResultType } from "@/types/employee";
import { AlertTriangle, CheckCircle, XCircle, TrendingUp, Percent } from "lucide-react";
import { cn } from "@/lib/utils";

interface PredictionResultProps {
  result: PredictionResultType | null;
  isLoading: boolean;
}

const PredictionResultCard = ({ result, isLoading }: PredictionResultProps) => {
  if (isLoading) {
    return (
      <Card className="shadow-card bg-card border-border">
        <CardHeader>
          <CardTitle className="font-display text-xl text-foreground flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-hr-teal" />
            Prediction Result
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12">
            <div className="h-16 w-16 animate-spin rounded-full border-4 border-hr-teal border-t-transparent mb-4" />
            <p className="text-muted-foreground">Analyzing employee data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!result) {
    return (
      <Card className="shadow-card bg-card border-border">
        <CardHeader>
          <CardTitle className="font-display text-xl text-foreground flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-hr-teal" />
            Prediction Result
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-secondary flex items-center justify-center mb-4">
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">
              Enter employee parameters and click "Get Prediction" to see the attrition prediction
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getRiskConfig = (riskLevel: string) => {
    switch (riskLevel) {
      case "high":
        return {
          icon: XCircle,
          color: "text-destructive",
          bgColor: "bg-destructive/10",
          borderColor: "border-destructive/30",
          label: "High Risk",
          description: "This employee has a high probability of leaving. Consider immediate retention strategies.",
        };
      case "medium":
        return {
          icon: AlertTriangle,
          color: "text-hr-warning",
          bgColor: "bg-hr-warning/10",
          borderColor: "border-hr-warning/30",
          label: "Medium Risk",
          description: "This employee shows moderate risk factors. Monitor closely and consider engagement initiatives.",
        };
      default:
        return {
          icon: CheckCircle,
          color: "text-hr-success",
          bgColor: "bg-hr-success/10",
          borderColor: "border-hr-success/30",
          label: "Low Risk",
          description: "This employee appears stable. Continue current management practices.",
        };
    }
  };

  const config = getRiskConfig(result.riskLevel);
  const Icon = config.icon;

  return (
    <Card className={cn(
      "shadow-card bg-card border-2 transition-all duration-300 animate-slide-up",
      config.borderColor
    )}>
      <CardHeader>
        <CardTitle className="font-display text-xl text-foreground flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-hr-teal" />
          Prediction Result
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Main Result */}
        <div className={cn(
          "rounded-xl p-6 text-center",
          config.bgColor
        )}>
          <div className="flex justify-center mb-4">
            <div className={cn(
              "h-20 w-20 rounded-full flex items-center justify-center",
              config.bgColor
            )}>
              <Icon className={cn("h-12 w-12", config.color)} />
            </div>
          </div>
          <h3 className={cn("text-2xl font-display font-bold mb-2", config.color)}>
            {config.label}
          </h3>
          <p className="text-foreground font-medium">
            Prediction: {result.prediction}
          </p>
        </div>

        {/* Probability */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Percent className="h-4 w-4" />
              Attrition Probability
            </span>
            <span className={cn("text-lg font-bold", config.color)}>
              {(result.probability * 100).toFixed(1)}%
            </span>
          </div>
          <div className="h-3 rounded-full bg-secondary overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all duration-1000 ease-out",
                result.riskLevel === "high" ? "bg-destructive" :
                result.riskLevel === "medium" ? "bg-hr-warning" : "bg-hr-success"
              )}
              style={{ width: `${result.probability * 100}%` }}
            />
          </div>
        </div>

        {/* Description */}
        <div className="p-4 rounded-lg bg-secondary/50 border border-border">
          <p className="text-sm text-muted-foreground">
            {config.description}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PredictionResultCard;
