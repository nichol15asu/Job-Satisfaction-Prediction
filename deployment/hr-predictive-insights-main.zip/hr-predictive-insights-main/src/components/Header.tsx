import { Users, BarChart3 } from "lucide-react";

const Header = () => {
  return (
    <header className="gradient-hero shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-card/20 backdrop-blur-sm">
              <Users className="h-7 w-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-primary-foreground">
                HR Analytics
              </h1>
              <p className="text-sm text-primary-foreground/80">
                Employee Attrition Prediction
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-card/20 px-4 py-2 backdrop-blur-sm">
            <BarChart3 className="h-5 w-5 text-primary-foreground" />
            <span className="text-sm font-medium text-primary-foreground">
              ML-Powered Insights
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
