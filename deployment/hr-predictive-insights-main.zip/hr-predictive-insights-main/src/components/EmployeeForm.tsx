import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import FormField from "./FormField";
import {
  EmployeeData,
  initialEmployeeData,
  BUSINESS_TRAVEL_OPTIONS,
  GENDER_OPTIONS,
  JOB_ROLE_OPTIONS,
  OVERTIME_OPTIONS,
  SATISFACTION_LEVELS,
  JOB_LEVELS,
  PERFORMANCE_RATINGS,
  WORK_LIFE_BALANCE_LEVELS,
} from "@/types/employee";
import {
  Briefcase,
  DollarSign,
  MapPin,
  Smile,
  User,
  TrendingUp,
  Clock,
  Star,
  Heart,
  Calendar,
  Building,
  UserCheck,
  Users,
  Send,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";

interface EmployeeFormProps {
  onSubmit: (data: EmployeeData) => void;
  isLoading: boolean;
}

const EmployeeForm = ({ onSubmit, isLoading }: EmployeeFormProps) => {
  const [formData, setFormData] = useState<EmployeeData>(initialEmployeeData);
  const [errors, setErrors] = useState<Partial<Record<keyof EmployeeData, string>>>({});

  const updateField = (field: keyof EmployeeData, value: string | number) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof EmployeeData, string>> = {};

    if (!formData.businessTravel) {
      newErrors.businessTravel = "Business Travel is required";
    }
    if (formData.dailyRate <= 0) {
      newErrors.dailyRate = "Daily Rate must be greater than 0";
    }
    if (formData.distanceFromHome < 0) {
      newErrors.distanceFromHome = "Distance cannot be negative";
    }
    if (!formData.environmentSatisfaction) {
      newErrors.environmentSatisfaction = "Environment Satisfaction is required";
    }
    if (!formData.gender) {
      newErrors.gender = "Gender is required";
    }
    if (!formData.jobLevel) {
      newErrors.jobLevel = "Job Level is required";
    }
    if (!formData.jobRole) {
      newErrors.jobRole = "Job Role is required";
    }
    if (!formData.overtime) {
      newErrors.overtime = "Overtime is required";
    }
    if (!formData.performanceRating) {
      newErrors.performanceRating = "Performance Rating is required";
    }
    if (!formData.workLifeBalance) {
      newErrors.workLifeBalance = "Work Life Balance is required";
    }
    if (formData.yearsSinceLastPromotion < 0) {
      newErrors.yearsSinceLastPromotion = "Years cannot be negative";
    }
    if (formData.yearsAtCompany < 0) {
      newErrors.yearsAtCompany = "Years cannot be negative";
    }
    if (formData.yearsInCurrentRole < 0) {
      newErrors.yearsInCurrentRole = "Years cannot be negative";
    }
    if (formData.yearsWithCurrentManager < 0) {
      newErrors.yearsWithCurrentManager = "Years cannot be negative";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    } else {
      toast.error("Please fill in all required fields correctly");
    }
  };

  const handleReset = () => {
    setFormData(initialEmployeeData);
    setErrors({});
    toast.success("Form has been reset");
  };

  return (
    <Card className="shadow-card hover:shadow-card-hover transition-all duration-300 bg-card border-border">
      <CardHeader className="pb-4">
        <CardTitle className="font-display text-xl text-foreground flex items-center gap-2">
          <Users className="h-5 w-5 text-hr-teal" />
          Employee Parameters
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Enter employee information for attrition prediction
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-hr-navy uppercase tracking-wide flex items-center gap-2">
              <User className="h-4 w-4" />
              Personal Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                label="Gender"
                name="gender"
                type="select"
                value={formData.gender}
                onChange={(val) => updateField("gender", val)}
                options={GENDER_OPTIONS}
                placeholder="Select gender"
                error={errors.gender}
                required
                icon={<User className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Distance from Home (miles)"
                name="distanceFromHome"
                type="number"
                value={formData.distanceFromHome}
                onChange={(val) => updateField("distanceFromHome", val)}
                placeholder="Enter distance"
                min={0}
                error={errors.distanceFromHome}
                required
                icon={<MapPin className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
          </div>

          {/* Job Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-hr-navy uppercase tracking-wide flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              Job Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <FormField
                label="Job Role"
                name="jobRole"
                type="select"
                value={formData.jobRole}
                onChange={(val) => updateField("jobRole", val)}
                options={JOB_ROLE_OPTIONS}
                placeholder="Select job role"
                error={errors.jobRole}
                required
                icon={<Briefcase className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Job Level"
                name="jobLevel"
                type="select"
                value={formData.jobLevel}
                onChange={(val) => updateField("jobLevel", Number(val))}
                options={JOB_LEVELS}
                placeholder="Select job level"
                error={errors.jobLevel}
                required
                icon={<TrendingUp className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Daily Rate ($)"
                name="dailyRate"
                type="number"
                value={formData.dailyRate}
                onChange={(val) => updateField("dailyRate", val)}
                placeholder="Enter daily rate"
                min={0}
                error={errors.dailyRate}
                required
                icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
          </div>

          {/* Work Patterns */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-hr-navy uppercase tracking-wide flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Work Patterns
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                label="Business Travel"
                name="businessTravel"
                type="select"
                value={formData.businessTravel}
                onChange={(val) => updateField("businessTravel", val)}
                options={BUSINESS_TRAVEL_OPTIONS}
                placeholder="Select travel frequency"
                error={errors.businessTravel}
                required
                icon={<Briefcase className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Overtime"
                name="overtime"
                type="select"
                value={formData.overtime}
                onChange={(val) => updateField("overtime", val)}
                options={OVERTIME_OPTIONS}
                placeholder="Select overtime status"
                error={errors.overtime}
                required
                icon={<Clock className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
          </div>

          {/* Satisfaction & Performance */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-hr-navy uppercase tracking-wide flex items-center gap-2">
              <Star className="h-4 w-4" />
              Satisfaction & Performance
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <FormField
                label="Environment Satisfaction"
                name="environmentSatisfaction"
                type="select"
                value={formData.environmentSatisfaction}
                onChange={(val) => updateField("environmentSatisfaction", Number(val))}
                options={SATISFACTION_LEVELS}
                placeholder="Select satisfaction"
                error={errors.environmentSatisfaction}
                required
                icon={<Smile className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Performance Rating"
                name="performanceRating"
                type="select"
                value={formData.performanceRating}
                onChange={(val) => updateField("performanceRating", Number(val))}
                options={PERFORMANCE_RATINGS}
                placeholder="Select rating"
                error={errors.performanceRating}
                required
                icon={<Star className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Work Life Balance"
                name="workLifeBalance"
                type="select"
                value={formData.workLifeBalance}
                onChange={(val) => updateField("workLifeBalance", Number(val))}
                options={WORK_LIFE_BALANCE_LEVELS}
                placeholder="Select balance"
                error={errors.workLifeBalance}
                required
                icon={<Heart className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
          </div>

          {/* Tenure Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-hr-navy uppercase tracking-wide flex items-center gap-2">
              <Building className="h-4 w-4" />
              Tenure Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <FormField
                label="Years at Company"
                name="yearsAtCompany"
                type="number"
                value={formData.yearsAtCompany}
                onChange={(val) => updateField("yearsAtCompany", val)}
                placeholder="Enter years"
                min={0}
                error={errors.yearsAtCompany}
                required
                icon={<Building className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Years in Current Role"
                name="yearsInCurrentRole"
                type="number"
                value={formData.yearsInCurrentRole}
                onChange={(val) => updateField("yearsInCurrentRole", val)}
                placeholder="Enter years"
                min={0}
                error={errors.yearsInCurrentRole}
                required
                icon={<UserCheck className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Years With Current Manager"
                name="yearsWithCurrentManager"
                type="number"
                value={formData.yearsWithCurrentManager}
                onChange={(val) => updateField("yearsWithCurrentManager", val)}
                placeholder="Enter years"
                min={0}
                error={errors.yearsWithCurrentManager}
                required
                icon={<Users className="h-4 w-4 text-muted-foreground" />}
              />
              <FormField
                label="Years Since Promotion"
                name="yearsSinceLastPromotion"
                type="number"
                value={formData.yearsSinceLastPromotion}
                onChange={(val) => updateField("yearsSinceLastPromotion", val)}
                placeholder="Enter years"
                min={0}
                error={errors.yearsSinceLastPromotion}
                required
                icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-border">
            <Button
              type="submit"
              variant="hr"
              size="lg"
              className="flex-1"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                  Processing...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Get Prediction
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={handleReset}
              disabled={isLoading}
            >
              <RotateCcw className="h-4 w-4" />
              Reset Form
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default EmployeeForm;
