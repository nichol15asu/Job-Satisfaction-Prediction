import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface FormFieldProps {
  label: string;
  name: string;
  type: "text" | "number" | "select";
  value: string | number;
  onChange: (value: string | number) => void;
  options?: { value: string | number; label: string }[];
  placeholder?: string;
  min?: number;
  max?: number;
  error?: string;
  required?: boolean;
  icon?: React.ReactNode;
}

const FormField = ({
  label,
  name,
  type,
  value,
  onChange,
  options,
  placeholder,
  min,
  max,
  error,
  required,
  icon,
}: FormFieldProps) => {
  return (
    <div className="space-y-2">
      <Label
        htmlFor={name}
        className={cn(
          "flex items-center gap-2 text-sm font-medium text-foreground",
          error && "text-destructive"
        )}
      >
        {icon}
        {label}
        {required && <span className="text-destructive">*</span>}
      </Label>

      {type === "select" && options ? (
        <Select
          value={String(value)}
          onValueChange={(val) => onChange(val)}
        >
          <SelectTrigger
            id={name}
            className={cn(
              "h-11 bg-card border-input focus:ring-2 focus:ring-ring transition-all duration-200",
              error && "border-destructive focus:ring-destructive"
            )}
          >
            <SelectValue placeholder={placeholder || `Select ${label}`} />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            {options.map((option) => (
              <SelectItem
                key={String(option.value)}
                value={String(option.value)}
                className="cursor-pointer hover:bg-accent"
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : (
        <Input
          id={name}
          type={type}
          value={value}
          onChange={(e) =>
            onChange(type === "number" ? Number(e.target.value) : e.target.value)
          }
          placeholder={placeholder}
          min={min}
          max={max}
          className={cn(
            "h-11 bg-card border-input focus:ring-2 focus:ring-ring transition-all duration-200",
            error && "border-destructive focus:ring-destructive"
          )}
        />
      )}

      {error && (
        <p className="text-xs text-destructive animate-fade-in">{error}</p>
      )}
    </div>
  );
};

export default FormField;
