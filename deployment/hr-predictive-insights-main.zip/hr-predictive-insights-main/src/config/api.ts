// API Configuration
// Replace these placeholders with your actual values

export const API_CONFIG = {
  // TODO: Replace with your actual API endpoint
  PREDICTION_ENDPOINT: "https://dbc-b1609c98-c6b8.cloud.databricks.com/serving-endpoints/job-satisfaction-endpoint/invocations",
  
  // TODO: Replace with your actual token
  TOKEN_ID: "dapie93ddc1ce92a774474231709b74dbb23",
};
