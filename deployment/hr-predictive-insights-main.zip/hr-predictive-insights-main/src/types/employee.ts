export interface EmployeeData {
  businessTravel: string;
  dailyRate: number;
  distanceFromHome: number;
  environmentSatisfaction: number;
  gender: string;
  jobLevel: number;
  jobRole: string;
  overtime: string;
  performanceRating: number;
  workLifeBalance: number;
  yearsSinceLastPromotion: number;
  yearsAtCompany: number;
  yearsInCurrentRole: number;
  yearsWithCurrentManager: number;
}

export interface PredictionResult {
  prediction: string;
  probability: number;
  riskLevel: 'low' | 'medium' | 'high';
}

export const BUSINESS_TRAVEL_OPTIONS = [
  { value: "Non-Travel", label: "Non-Travel" },
  { value: "Travel_Rarely", label: "Travel Rarely" },
  { value: "Travel_Frequently", label: "Travel Frequently" },
];

export const GENDER_OPTIONS = [
  { value: "Male", label: "Male" },
  { value: "Female", label: "Female" },
];

export const JOB_ROLE_OPTIONS = [
  { value: "Healthcare Representative", label: "Healthcare Representative" },
  { value: "Human Resources", label: "Human Resources" },
  { value: "Laboratory Technician", label: "Laboratory Technician" },
  { value: "Manager", label: "Manager" },
  { value: "Manufacturing Director", label: "Manufacturing Director" },
  { value: "Research Director", label: "Research Director" },
  { value: "Research Scientist", label: "Research Scientist" },
  { value: "Sales Executive", label: "Sales Executive" },
  { value: "Sales Representative", label: "Sales Representative" },
];

export const OVERTIME_OPTIONS = [
  { value: "Yes", label: "Yes" },
  { value: "No", label: "No" },
];

export const SATISFACTION_LEVELS = [
  { value: 1, label: "1 - Low" },
  { value: 2, label: "2 - Medium" },
  { value: 3, label: "3 - High" },
  { value: 4, label: "4 - Very High" },
];

export const JOB_LEVELS = [
  { value: 1, label: "Level 1 - Entry" },
  { value: 2, label: "Level 2 - Junior" },
  { value: 3, label: "Level 3 - Mid" },
  { value: 4, label: "Level 4 - Senior" },
  { value: 5, label: "Level 5 - Executive" },
];

export const PERFORMANCE_RATINGS = [
  { value: 1, label: "1 - Low" },
  { value: 2, label: "2 - Good" },
  { value: 3, label: "3 - Excellent" },
  { value: 4, label: "4 - Outstanding" },
];

export const WORK_LIFE_BALANCE_LEVELS = [
  { value: 1, label: "1 - Bad" },
  { value: 2, label: "2 - Good" },
  { value: 3, label: "3 - Better" },
  { value: 4, label: "4 - Best" },
];

export const initialEmployeeData: EmployeeData = {
  businessTravel: "",
  dailyRate: 0,
  distanceFromHome: 0,
  environmentSatisfaction: 0,
  gender: "",
  jobLevel: 0,
  jobRole: "",
  overtime: "",
  performanceRating: 0,
  workLifeBalance: 0,
  yearsSinceLastPromotion: 0,
  yearsAtCompany: 0,
  yearsInCurrentRole: 0,
  yearsWithCurrentManager: 0,
};
