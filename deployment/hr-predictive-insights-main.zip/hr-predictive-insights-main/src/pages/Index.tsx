import { useState } from "react";
import Header from "@/components/Header";
import EmployeeForm from "@/components/EmployeeForm";
import PredictionResultCard from "@/components/PredictionResult";
import { EmployeeData, PredictionResult } from "@/types/employee";
import { getPrediction, getMockPrediction } from "@/services/predictionService";
import { API_CONFIG } from "@/config/api";
import { toast } from "sonner";
import { AlertCircle, Settings } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const Index = () => {
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const isAPIConfigured = 
    API_CONFIG.PREDICTION_ENDPOINT !== "YOUR_API_ENDPOINT_HERE" &&
    API_CONFIG.TOKEN_ID !== "YOUR_TOKEN_ID_HERE";

  const handleSubmit = async (data: EmployeeData) => {
    setIsLoading(true);
    setPrediction(null);

    try {
      let result: PredictionResult;
      
      if (isAPIConfigured) {
        result = await getPrediction(data);
        toast.success("Prediction completed successfully!");
      } else {
        // Use mock prediction when API is not configured
        await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API delay
        result = getMockPrediction(data);
        toast.info("Using mock prediction (API not configured)");
      }
      
      setPrediction(result);
    } catch (error) {
      console.error("Prediction error:", error);
      toast.error("Failed to get prediction. Please check your API configuration.");
      // Fallback to mock prediction
      const mockResult = getMockPrediction(data);
      setPrediction(mockResult);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* API Configuration Notice */}
        {!isAPIConfigured && (
          <Alert className="mb-6 border-hr-warning/30 bg-hr-warning/10 animate-fade-in">
            <Settings className="h-4 w-4 text-hr-warning" />
            <AlertTitle className="text-hr-warning font-semibold">API Configuration Required</AlertTitle>
            <AlertDescription className="text-foreground/80">
              To use the ML model, update the API endpoint and token in{" "}
              <code className="px-1.5 py-0.5 rounded bg-secondary text-sm font-mono">
                src/config/api.ts
              </code>
              . Currently using mock predictions for demonstration.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2">
            <EmployeeForm onSubmit={handleSubmit} isLoading={isLoading} />
          </div>

          {/* Result Section */}
          <div className="lg:col-span-1">
            <div className="sticky top-8">
              <PredictionResultCard result={prediction} isLoading={isLoading} />
              
              {/* Quick Stats Card */}
              <div className="mt-6 p-4 rounded-xl bg-card shadow-card border border-border">
                <h4 className="font-display font-semibold text-foreground mb-3 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-hr-teal" />
                  Key Factors
                </h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-hr-teal mt-1.5 flex-shrink-0" />
                    Overtime significantly impacts attrition risk
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-hr-teal mt-1.5 flex-shrink-0" />
                    Work-life balance is a critical indicator
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-hr-teal mt-1.5 flex-shrink-0" />
                    Years since promotion affects retention
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-hr-teal mt-1.5 flex-shrink-0" />
                    Environment satisfaction drives engagement
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-12 py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>HR Analytics Platform • Employee Attrition Prediction</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
