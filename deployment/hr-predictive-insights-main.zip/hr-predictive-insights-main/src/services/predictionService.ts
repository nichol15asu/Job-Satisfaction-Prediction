import { API_CONFIG } from "@/config/api";
import { EmployeeData, PredictionResult } from "@/types/employee";

export const getPrediction = async (employeeData: EmployeeData): Promise<PredictionResult> => {
  // Transform data to match expected API format
  const payload = {
    BusinessTravel: employeeData.businessTravel,
    DailyRate: employeeData.dailyRate,
    DistanceFromHome: employeeData.distanceFromHome,
    EnvironmentSatisfaction: employeeData.environmentSatisfaction,
    Gender: employeeData.gender,
    JobLevel: employeeData.jobLevel,
    JobRole: employeeData.jobRole,
    OverTime: employeeData.overtime,
    PerformanceRating: employeeData.performanceRating,
    WorkLifeBalance: employeeData.workLifeBalance,
    YearsSinceLastPromotion: employeeData.yearsSinceLastPromotion,
    YearsAtCompany: employeeData.yearsAtCompany,
    YearsInCurrentRole: employeeData.yearsInCurrentRole,
    YearsWithCurrManager: employeeData.yearsWithCurrentManager,
  };

  try {
    const response = await fetch(API_CONFIG.PREDICTION_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${API_CONFIG.TOKEN_ID}`,
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();
    
    // Transform API response to our format
    // Adjust this based on your actual API response structure
    const probability = data.probability ?? data.attrition_probability ?? 0.5;
    const prediction = data.prediction ?? (probability > 0.5 ? "Likely to Leave" : "Likely to Stay");
    
    let riskLevel: 'low' | 'medium' | 'high' = 'low';
    if (probability > 0.7) {
      riskLevel = 'high';
    } else if (probability > 0.4) {
      riskLevel = 'medium';
    }

    return {
      prediction,
      probability,
      riskLevel,
    };
  } catch (error) {
    console.error("Prediction API error:", error);
    throw error;
  }
};

// Mock prediction for testing when API is not available
export const getMockPrediction = (employeeData: EmployeeData): PredictionResult => {
  // Simple mock logic based on some parameters
  let riskScore = 0;
  
  if (employeeData.overtime === "Yes") riskScore += 0.2;
  if (employeeData.workLifeBalance <= 2) riskScore += 0.15;
  if (employeeData.environmentSatisfaction <= 2) riskScore += 0.15;
  if (employeeData.yearsSinceLastPromotion > 3) riskScore += 0.1;
  if (employeeData.yearsAtCompany < 2) riskScore += 0.1;
  if (employeeData.distanceFromHome > 20) riskScore += 0.1;
  if (employeeData.businessTravel === "Travel_Frequently") riskScore += 0.1;
  
  const probability = Math.min(riskScore + 0.1, 0.95);
  
  let riskLevel: 'low' | 'medium' | 'high' = 'low';
  if (probability > 0.6) {
    riskLevel = 'high';
  } else if (probability > 0.35) {
    riskLevel = 'medium';
  }

  return {
    prediction: probability > 0.5 ? "Likely to Leave" : "Likely to Stay",
    probability,
    riskLevel,
  };
};
